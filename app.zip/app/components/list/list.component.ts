import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  @Input('data') data: string[];

  public users: {}[] = [{
    'name': 'moustafa',
    'age': 30
  }, {
    'name': 'ahmed',
    'age': 33
  }, {
    'name': 'lily',
    'age': 33
  }];

  constructor() { }

  ngOnInit() {
    console.log(this.data);
  }

}
