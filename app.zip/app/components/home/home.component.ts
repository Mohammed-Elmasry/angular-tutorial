import { Component, OnInit } from '@angular/core';
import { UserModel } from 'src/app/models/User.model';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public name: string = "Moustafa";
  public students: string[] = ["", "ahmed", "lily"];
  public data: UserModel[] = [{
    name: 'ali',
    age: 20
  }, {
    name: 'soaad',
    age: 18
  }];

  constructor(private router: Router, private route: ActivatedRoute) {
    // this.alertName();
    console.log(this.route.params['value'])
  }

  alertName(): void {
    alert(this.name);
  }

  setMyName(name: string): string {
    return name;
  }

  navigateTo(path: string): void {
    this.router.navigate([path]);
  }

  ngOnInit() {
  }

}
