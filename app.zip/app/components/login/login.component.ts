import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public customers: string[] = ["Ahmed", "Ali", "Soad"];

  constructor(private router: Router) {}

  goTo(pathName: string): void {
    this.router.navigate([pathName]);
  }

  navigateTo(path: string): void {
    this.router.navigate([path, 5]);
  }

  ngOnInit() {
  }

}
