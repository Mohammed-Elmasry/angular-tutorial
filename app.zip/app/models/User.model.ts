export interface UserModel {
    name: string;
    age: number;
};